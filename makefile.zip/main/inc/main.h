#ifndef TEST_MAIN_H
#define TEST_MAIN_H
typedef struct point { int row, col; } item_t;

#define MAX_ROW 5
#define MAX_COL 5

#endif //TEST_MAIN_H
