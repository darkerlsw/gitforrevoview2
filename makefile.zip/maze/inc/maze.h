#ifndef TEST_MAZE_H
#define TEST_MAZE_H
#include "main.h" /* provides defination for MAX_ROW and MAX_COL */

extern int maze[MAX_ROW][MAX_COL];
void print_maze(void);
#endif //TEST_MAZE_H
