package com.aliyun.alink.devicesdk.demo;

import java.io.Serializable;

public class ThingData implements Serializable {
    public String type;
    public String identifier;
    public String value;
}
