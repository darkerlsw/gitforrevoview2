void get_msgid(char *payload, int is_cloud);
int check_target_msg(const char *input, int len);
void send_permance_info(char *input, int input_len, char *comments, int report_format);
